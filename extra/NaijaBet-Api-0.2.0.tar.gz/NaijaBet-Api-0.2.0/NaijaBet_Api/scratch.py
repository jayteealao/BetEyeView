
import pathlib
import collections
import json, re

p = pathlib('Naijabet_Api/utils/nairabet_normalizer.json')
f = open(p.absolute(), 'r')

jsondata = json.load(f, object_pairs_hook=collections.OrderedDict)

for datum in data:
    teams = datum["match"]
    print(teams)
    home, away = re.split(r'\s-\s', teams, maxsplit=1)
    jsondata.setdefault(home.strip(), home.strip())
    print(home)
    jsondata.setdefault(away.strip(), away.strip())
    print(away)
