# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['naijabet_api',
 'naijabet_api.bookmakers',
 'naijabet_api.schema',
 'naijabet_api.utils']

package_data = \
{'': ['*']}

install_requires = \
['arrow>=1.1.1,<2.0.0',
 'black>=21.7b0,<22.0',
 'coverage>=5.5,<6.0',
 'jmespath>=0.10.0,<0.11.0',
 'requests>=2.25.1,<3.0.0']

setup_kwargs = {
    'name': 'naijabet-api',
    'version': '0.2.0',
    'description': '',
    'long_description': None,
    'author': 'graphitenerd',
    'author_email': 'jayteealao@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
