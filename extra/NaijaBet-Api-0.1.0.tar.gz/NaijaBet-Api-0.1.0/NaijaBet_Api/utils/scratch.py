import jmespath

bet9ja = ('D.E[*].{"match": DS, '
          '"league": GN, '
          '"time": STARTDATE, '
          '"league_id": GID, '
          '"match_id": ID, '
          '"home": O.S_1X2_1 '
          '"draw": O.S_1X2_X '
          '"away": O.S_1X2_2 '
          '"home_or_draw": O.S_DC_1X '
          '"home_or_away": O.S_DC_12 '
          '"draw_or_away": O.S_DC_X2 '
          '}')


def string_provider(string):
    search_string = string

    def decorator(func):
        # print(search_string)

        def wrapper(*args, **kwargs):
            json, = args
            
            func(json, search_string=search_string)
        return wrapper
    return decorator


@string_provider(bet9ja)
def bet9ja_data_clean(json, **kwargs):
    search_string, = kwargs.values()
    print(search_string)
    expression = jmespath.compile(search_string)
    return expression.search(json)