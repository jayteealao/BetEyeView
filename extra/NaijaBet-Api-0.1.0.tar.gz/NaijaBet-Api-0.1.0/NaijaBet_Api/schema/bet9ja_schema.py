import colander


class E(colander.SequenceSchema):
    @colander.instantiate()
    class event(colander.MappingSchema):
        # C = colander.SchemaNode(colander.String())
        DS = colander.SchemaNode(colander.String())
        ENDVISIBILITYDATE = colander.SchemaNode(colander.String())
        # EXTID = colander.SchemaNode(colander.String())
        GID = colander.SchemaNode(colander.Int())
        GN = colander.SchemaNode(colander.String())
        # GP = colander.SchemaNode(colander.Int())
        ID = colander.SchemaNode(colander.Int())
        # INCTYPE = colander.SchemaNode(colander.Int())
        # MKNUM = colander.SchemaNode(colander.Int())
        O = colander.SchemaNode(colander.Mapping(unknown="preserve"))  # noqa: E741
        # P = colander.SchemaNode(colander.Int())
        # PL = colander.SchemaNode(colander.Int())
        # PRV = colander.SchemaNode(colander.Int())
        SG = colander.SchemaNode(colander.String())
        SGID = colander.SchemaNode(colander.Int())
        # SID = colander.SchemaNode(colander.Int())
        SPORT = colander.SchemaNode(colander.String())
        # ST = colander.SchemaNode(colander.Int())
        STARTDATE = colander.SchemaNode(colander.String())
        # TYPE = colander.SchemaNode(colander.Int())
